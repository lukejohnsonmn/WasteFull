READ_ME.txt

******************************
IMPORTANT

If "index.html" does not display/function properly
(i.e. no colors and links do not work),
please open and then close the following files:

- "style.css"
- "wasteStyle.css"
- "wasteFull.html"
- "SalesPitch.pdf"
- "transitions.js"

Then re-open "index.html" and the problems should be resolved.
******************************

Contents:
"index.html"        - The main website that contains the IoT Project Showcase.
"SalesPitch.pdf"    - The project overview/sales pitch
"style.css"         - Styling for "index.html"
"title.txt"         - Title of project
"transitions.js"    - Transitions for "index.html"
"wasteFull.html"    - Interactive website used to communicate with the photon.
"wasteStyle.css"    - Styling for "wasteFull.html"
